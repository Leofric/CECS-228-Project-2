//
//  myDate.hpp
//  Project2
//
//  Created by Alex Berthon on 9/26/16.
//  Copyright © 2016 Alex Berthon. All rights reserved.
//

#ifndef myDate_hpp
#define myDate_hpp

#include <stdio.h>
class myDate {
private:
    int day;
    int month;
    int year;
    int JD;
public:
    myDate();
    myDate(int m, int d, int y);
    void display();
    void incrDate(int n);
    void decrDate(int n);
    int daysBetween(myDate d);
    int getMonth();
    int getDay();
    int getYear();
    int getYearOffset();
    
    int sign(int x);
    void convert(int x);
};

#endif /* myDate_hpp */
