//
//  myDate.cpp
//  Project2
//
//  Created by Alex Berthon on 9/26/16.
//  Copyright © 2016 Alex Berthon. All rights reserved.
//

#include "myDate.hpp"
#include <iostream>

//default constructor, sets date to 5/11/1959
myDate::myDate(){
    month = 5;
    day = 11;
    year = 1959;
    JD = 367*year - (7*(year+(month+9)/12))/4 + (275*month)/9 + day + 1721013.5 - 0.5*sign(100*year+month-190002.5) + 0.5;
}

//overloaded constructor, sets date to arguments if valid, else sets to default, 5/11/1959
myDate::myDate(int m, int d, int y){
    if (m<1 || m>12 || d<1 || d>31 || y<1 || y>2099 || y<1801){
        std::cout<<"Invalid input"<<std::endl;
        month = 5;
        day = 11;
        year = 1959;
    }
    else{
        month = m;
        day = d;
        year = y;
        JD = 367*y-(7*(y+(m+9)/12))/4 + (275*m)/9 + d + 1721013.5 - 0.5*sign(100*y+m-190002.5) + 0.5;
    }
}

//formats the output
void myDate::display(){
    std::string printMonth;
    switch (month) {
        case 1:
            printMonth = "January";
            break;
        case 2:
            printMonth = "Febuary";
            break;
        case 3:
            printMonth = "March";
            break;
        case 4:
            printMonth = "April";
            break;
        case 5:
            printMonth = "May";
            break;
        case 6:
            printMonth = "June";
            break;
        case 7:
            printMonth = "July";
            break;
        case 8:
            printMonth = "August";
            break;
        case 9:
            printMonth = "September";
            break;
        case 10:
            printMonth = "October";
            break;
        case 11:
            printMonth = "November";
            break;
        case 12:
            printMonth = "December";
            break;
    }
    
    std::cout<<printMonth<<" "<<day<<" "<<year<<std::endl;

}

//changes the date by +n number of days
void myDate::incrDate(int n){
    if(n<0){
        std::cout<<"Invalid input, please enter a positive int value"<<std::endl;
    }
    else{
        JD = JD + n;
        convert(JD);
    }
}

//changes the date by -n number of days
void myDate::decrDate(int n){
    if(n<0){
        std::cout<<"Invalid input, please enter a positive int value"<<std::endl;
    }
    else{
        JD = JD - n;
        convert(JD);
    }
}

//calculates the number of days between the given date and the current date
int myDate::daysBetween(myDate d){
    int inputDate = 367*d.getYear()-(7*(d.getYear()+(d.getMonth()+9)/12))/4 + (275*d.getMonth())/9 + d.getDay() + 1721013.5 - 0.5*sign(100*d.getYear()+d.getMonth()-190002.5) + 0.5;
    
    return abs(inputDate - JD);

}

int myDate::getMonth(){
    return month;
}
int myDate::getDay(){
    return day;
}
int myDate::getYear(){
    return year;
}

//returns the number of days since the start of the year
int myDate::getYearOffset(){
    myDate d(1,1,year);
    return daysBetween(d);
}

//used in the Julian date formula
int myDate::sign(int x){
    int sign = 1;
    if(x<0){
        sign = -1;
    }
    return sign;
}

//used to convert Julian date to calendar date
void myDate::convert(int x){
    int l, n, i, j, k;
    l= x+68569;
    n= 4*l/146097;
    l= l-(146097*n+3)/4;
    i= 4000*(l+1)/1461001;
    l= l-1461*i/4+31;
    j= 80*l/2447;
    k= l-2447*j/80;
    l= j/11;
    j= j+2-12*l;
    i= 100*(n-49)+i+l;
    
    month = j;
    day = k+1;
    year = i;
}
